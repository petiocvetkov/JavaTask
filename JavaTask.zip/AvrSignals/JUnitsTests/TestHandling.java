import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestHandling {

	@Test
	void testHandling() {
		String input = "[\n" + 
				"{\n" + 
				"\"stationName\":\"MySSID\",\n" + 
				"\"power\":-10\n" + 
				"},\n" + 
				"{\n" + 
				"\"stationName\":\"Appolica\",\n" + 
				"\"power\":-15\n" + 
				"},\n" + 
				"{\n" + 
				"\"stationName\":\"MySSID\",\n" + 
				"\"power\":-1\n" + 
				"},\n" + 
				"{\n" + 
				"\"stationName\":\"Appolica\",\n" + 
				"\"power\":-5\n" + 
				"},\n" + 
				"{\"stationName\":\"Appolica\",\n" + 
				"\"power\":-50\n" + 
				"}\n" + 
				"]\n" + 
				""
		String res = "[\n" + 
				"    {\n" + 
				"        \"stationName\": \"MySSID\",\n" + 
				"        \"avaragePower\": -5.5\n" + 
				"    },\n" + 
				"    {\n" + 
				"        \"stationName\": \"Appolica\",\n" + 
				"        \"avaragePower\": -23.333333333333332\n" + 
				"    }\n" + 
				"]"
		Junit test = new Junit();
		String result = test.handleInput(input);
		assertEquals(res,result);
	}

}
